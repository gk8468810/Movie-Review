#include<iostream>
using namespace std;

class tree
{
public:
    int data;
    tree* LC;
    tree* RC;
    tree(int value)
    {
        data=value;
        LC=NULL;
        RC=NULL;

    }

    void creattree(tree* root){
        int n;
        cin>>n;
        root->value=n;

        if(root->value==-1){
            return;
        }

        cout<<"enter value in left of"<<root<<endl;
        root->left=creattree(root->left);
        cout<<"enter value in right of"<<root<<endl;
        root->right=creattree(root->tree);
    }
};



void inorder(tree* root){
    if(root->value!=NULL){
        inorder(root->left);
        cout<<root->value;
        inorder(root->right);
    }


    
}


int main()
{
    tree* root;
    creattree(root);

return 0;
}