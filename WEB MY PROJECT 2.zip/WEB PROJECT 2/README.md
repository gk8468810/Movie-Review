# IMDBclone
A dynamic website created using HTML, CSS and JS.
